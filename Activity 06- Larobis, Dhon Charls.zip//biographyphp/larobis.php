<?php 

$mysqli = mysqli_connect("user_account", "user", "password", "database");

$result = mysqli_query($mysqli, "Dhon Charls Larobis full of' AS_msg FROM DUAL");
$row = mysqli_fetch_assoc($result);
echo $row['_msg'];

$result - $mysqli->query("SELECT 'Agnawe, Agsungot, Cebu.' AS _msg FROM DUAL" );
$row = $result ->fetch_assoc( );
echo $row[' _msg'];





